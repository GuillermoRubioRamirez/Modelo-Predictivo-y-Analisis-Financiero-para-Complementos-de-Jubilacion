# Azul Claro

En este readme se detallará la estructura que tiene este proyecto de Python. El proyecto contiene una carpeta con los datos, seis notebooks (01-data_discovery_cleaning, 02-modelos, 03-calculos_financieros, 04.1-inflacion_calculos_previos, 04.2-escenario_inflacion, 05-escenario_rendimiento y funciones_calculos_financieros.py) y un archivo .yml con el contenido necesario para crear el entorno que se ha utilizado para realizar el reto.

En cuanto a la carpeta de datos, dentro se encuentran otras dos carpetas, una con los datos originales y otra con los datos limpios. Los datos originales son los que nos proporcionó Lagun Aro al principio y otros dos dataset que se buscaron para realizar los escenarios de la inflación y el rendimiento esperado, y los datos limpios son los que se han ido generando a lo largo del reto.

En lo que respecta a los notebooks, el primero contiene el código necesario para limpiar los tres datasets y realizar graficos descriptivos. Se generan tres archivos .csv llamados df1, df2 y df3, respectivamente.

El segundo notebook contiene todo lo que respecta al modelado de datos y al analisis descriptivo.

El tercero contiene el calculo de las rentas haciendo uso de las funciones que contiene el notebook funciones_calculos-financieros.py.

El cuarto partiendo del dataset que se ha buscado en Internet sobre los datos historicos de la inflación, se ha modificado el df que nos habian proporcionado sobre la evolucion del IPC, con el objetivo de realizar cuatro escenarios diferentes. Se generan cuatro archivos .csv en función de los cuatro escenarios diferentes planteados. 

El notebook 4.1 contiene los calculos que se han realizado en funcion de los diferentes cuatro escenarios sobre la inflación, en este caso, tambien se han utilizado las funciones que contiene el notebook funciones_calculos_financieros.py

Por último, el quinto notebook contiene los calculos que se han realizado cambiando el tipo de interes segun el escenario planteado. en este caso, tambien se han utilizado las funciones que contiene el notebook funciones_calculos_financieros.py.
