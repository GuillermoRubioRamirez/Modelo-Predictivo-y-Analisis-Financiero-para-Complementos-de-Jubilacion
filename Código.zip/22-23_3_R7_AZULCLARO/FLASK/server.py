# Carga de librerias --------------------------------------------------------------------------
from flask import Flask, request, render_template, session
import pandas as pd
import logging
import funciones.funcion as fun
from funciones.funcion_calculos_financieros import *
import bbdd.con_sql as sql

# Configuraciones -----------------------------------------------------------------------------
logging.basicConfig(
    level = logging.DEBUG,
    filename = 'app.log', 
    filemode = 'w',
    format = '%(asctime)s :: %(levelname)-8s :: %(message)s', 
    datefmt = '%d-%b-%y %H:%M:%S'
)

sql.crear_tabla()

# App Flask -----------------------------------------------------------------------------------
app = Flask(__name__)
app.secret_key = 'azulclaro'

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/contexto_reto')
def contexto():
    return render_template('contexto_reto.html')

@app.route('/objetivos_reto')
def objetivos():
    return render_template('objetivos_reto.html')

@app.route('/login', methods = ['GET', 'POST'])
def identificarse():
    if request.method == 'POST':
        user = request.form.get('user')
        pw = request.form.get('pw')
        if user == 'reto07' and pw == 'azulclaro':
            logging.info('Acceso')
            return render_template ('acceso.html')
        logging.warning(f'Usuario o contraseña incorrecto por el usuario {user}')
        mensaje = 'Usuario o contraseña incorrecto. Intentelo de nuevo.'
        return render_template('identificarse.html', mensaje = mensaje)
    return render_template('identificarse.html', mensaje = '')

@app.route('/calculo_jubilacion', methods = ['GET', 'POST'])
def calc_jubil():
    if request.method == 'POST':
        nombre = request.form.get('nombre')
        session['nombre'] = nombre
        apellido1 = request.form.get('apellido1')
        apellido2 = request.form.get('apellido2')
        dni = request.form.get('dni')
        session['dni'] = dni
        fecha_nac = pd.to_datetime(request.form.get('fecha_nac'))
        session['fecha_nac'] = fecha_nac
        fecha_entrada = pd.to_datetime(request.form.get('fecha_entrada'))
        session['fecha_entrada'] = fecha_entrada
        nomina = float(request.form.get('nomina'))
        tipos = float(request.form.get('tipos'))
        session['tipos'] = tipos
        rendimiento = float(request.form.get('rendimiento'))
        session['rendimiento'] = rendimiento

        df = pd.DataFrame([[fecha_nac, fecha_entrada, nomina]], columns = ['FECHA NAC','FECHA ENTRADA','NOMINA BRUTA 01/01/2024'])

        resultados = []
        i2 = [0] + [tipos]
        q2 = [0] + [rendimiento]
        for i_val, q_val in zip(i2, q2):
            vs_jub, M, VA_2024 = zip(*df.apply(fun.calcular_rentas, args=(0, i_val, q_val), axis=1))
            resultados.append((vs_jub[0], M[0], VA_2024[0]))
        df_resultados = pd.DataFrame(resultados, columns=['vs_jub', 'M', 'VA_2024'])
        vs = df_resultados['vs_jub'][1]
        session['vs'] = vs
        m = df_resultados['M'][1]
        session['m'] = m
        va = df_resultados['VA_2024'][1]
        session['va'] = va

        sql.insertar_valores(dni=dni, vs=vs, m=m, va=va)

        return render_template('resultados.html', nombre=nombre, apellido1=apellido1, apellido2=apellido2, vs=vs, m=m, va=va, 
                               tipos=tipos, rendimiento=rendimiento)
    return render_template('form_datos.html')

@app.route('/estadisticas', methods = ['GET'])
def estadisticas():
    results = sql.consultar_valores()
    return render_template('estadisticas.html', results=results)

if __name__ == "__main__":
    app.run(debug = True)
