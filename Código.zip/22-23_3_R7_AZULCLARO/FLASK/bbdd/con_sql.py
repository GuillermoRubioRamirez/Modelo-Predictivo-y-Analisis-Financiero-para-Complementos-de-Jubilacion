import sqlite3 as sqlite

nombre_bbdd = 'registro.db'

def crear_tabla():
    con = sqlite.connect(nombre_bbdd)
    cur = con.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS registro(
                dni TEXT NOT NULL,
                vs REAL NOT NULL,
                m REAL NOT NULL,
                va REAL NOT NULL)""")
    con.close()
    return None

def insertar_valores(dni, vs, m, va):
    con = sqlite.connect(nombre_bbdd)
    cur = con.cursor()
    cur.execute("""INSERT INTO registro VALUES (?,?,?,?)""",
                (dni, vs, m, va))
    con.commit()
    con.close()
    return None

def consultar_valores():
    con = sqlite.connect(nombre_bbdd)
    cur = con.cursor()
    cur.execute("SELECT * FROM registro")
    resultados = cur.fetchall()
    con.close()
    return resultados