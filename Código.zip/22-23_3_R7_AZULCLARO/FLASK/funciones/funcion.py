from funciones.funcion_calculos_financieros import *

def calcular_rentas(row, n=0, i=0, q=0):

    #1.- calcular salario.

    row = calcular_salario(row,n)

    #2. calcuar el VA de las rentas a 2024
    row = calculo_rentas_VA_i(row,n, i, q)
    
    #3. calcular el M, pero solo en el tiempo original, es decir, cuando n = 0. en nuestro caso son 761 meses.
    if n == 0:
        row = calcular_renta_mensual(row,n)
    #4. con el M obtenido, conseguir 

    ### comparacion
    
    return row[f'RENTA_F_{n}'], row['M'], row[f'ACTU_2024_{n}_(VA)']


def resultados(i, q):

    resultados = []

    i2 = [0] + [i]
    q2 = [0] + [q]

    df = pd.DataFrame()

    # Aplicar la función para cada combinación de valores de i y q
    for i_val, q_val in zip(i2, q2):
        # Aplicar la función a cada fila del DataFrame y desempaquetar la tupla resultante
        vs_jub, M, VA_2024 = zip(*df.apply(calcular_rentas, args=(0, i_val, q_val), axis=1))
        resultados.append((vs_jub[0], M[0], VA_2024[0]))

    # Convertir la lista de resultados en un DataFrame si es necesario
    df_resultados = pd.DataFrame(resultados, columns=['vs_jub', 'M', 'VA_2024'])

    # Mostrar el resultado si es necesario
    return df_resultados