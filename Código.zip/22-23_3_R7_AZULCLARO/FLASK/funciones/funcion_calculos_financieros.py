
import pandas as pd
from datetime import datetime, timedelta
from dateutil.relativedelta import *
import math
import matplotlib.pyplot as plt
import numpy as np


###########################################################################
# FUNCION PARA CALCULAR EL SALARIO, DEPENDIENDO DE LA EDAD , N.

def calcular_salario(row, n):

    df2 = pd.read_csv('../DATOS/LIMPIOS/df2.csv')
    media = pd.read_csv('../DATOS/LIMPIOS/valores.csv')['media'].item()

    # cuanto tiempo antes o despues? por eso + n
    media_años = (media+n) / 12
    media_redondeada = math.ceil(media_años)
    # buscamos un mes antes de la jubilacion, por eso -1
    media_un_año_antes = media_redondeada - 1

    meses = 11  # siempres, porque como redondeamos hacia arriba los años, siempre seran 63,64,65 y para calcular el mes anterior a esa fecha, elejimos 64-1 y11 meses
    today = pd.to_datetime('2024-01-01', format='%Y-%m-%d')
    f_jub = row['FECHA NAC'] + \
        relativedelta(years=media_un_año_antes, months=meses)
    dif = relativedelta(f_jub, today)

    row['años_hasta_jubilacion'] = dif.years
    row['meses_hasta_jubilacion'] = dif.months
    row['dias_hasta_jubilacion'] = dif.days
    row['año_jub'] = f_jub.year
    row['fecha_jubilacion'] = f_jub + relativedelta(months=1)
    if n == 0:
        row['fecha_jubilacion_base'] = f_jub + relativedelta(months=1)
# nos interesa guardar la fecha de jubilacion del año base, porque sino cada vez que ejecutemos el codigo, el año de jubilacion sera el anterior, y eso para el calculo de primas es erroneo.
    nomina = row['NOMINA BRUTA 01/01/2024']

    nominas_años = []
    for j in range(len(df2)):
        if j == 0:
            nominas_años.append(nomina + nomina*df2.at[j, 'TIPO'])
        else:
            incremento_nominas = nominas_años[j-1]*df2.at[j, 'TIPO']
            nominas_años.append(nominas_años[j-1] + incremento_nominas)
            if df2.at[j, 'AÑO'] > row['año_jub']:
                break
    row['salario_anual'] = nominas_años[-1]

    return row


###########################################################################
# FUNCION PARA CALCULAR EL VA de cada N.

def calculo_rentas_VA(row, n=0):
    fecha_jubilacion_exacta = pd.to_datetime(
        str(row['fecha_jubilacion'].strftime('%Y-%m')) + '-01').tz_localize(None)

    row['fecha_jubilacion_exacta'] = fecha_jubilacion_exacta
    # Calculamos los años en la empresa y n de periodos de 5 años en la empresa
    anos_en_empresa = (fecha_jubilacion_exacta.year -
                       row['FECHA ENTRADA'].year)
    periodos_5_anos = anos_en_empresa // 5

    # Condicion de no pasar del 15%
    if periodos_5_anos * 0.0175 > 0.15:
        value = 0.15
    else:
        value = periodos_5_anos * 0.0175

    # Valores constantes
    n_meses_i1 = 5 * 12 + 6
    interes1 = 0.01
    interes2 = 0.02
    i_mensual_1 = (1.01) ** (1/12) - 1
    i_mensual_2 = (1.02) ** (1/12) - 1
    k = 12
    q = 1.05
    j1 = k * i_mensual_1
    j2 = k * i_mensual_2

    # RENTAS JUBILADOS DE ENERO A MAYO
    if fecha_jubilacion_exacta.month in range(1, 5+1):

        # Calculamos la primera renta (normal)
        n1 = 12 - fecha_jubilacion_exacta.month
        M1 = (row['salario_anual'] * value) / 12
        primera_renta = M1 * (1 - (1 + i_mensual_1) ** -n1) / i_mensual_1

        # Calculamos la segunda renta (geométrica)
        n2 = 4
        M2 = M1 * q * 12
        C02 = interes1 / j1 * M2 * \
            (1 - (q ** n2) * (1 + interes1) ** -n2) / (1 + interes1 - q)
        segunda_renta = C02 * (1 + i_mensual_1) ** (-n1)

        # Calculamos la tercera renta (normal)
        n3 = n_meses_i1 - (n1 + 4*12)
        M6 = M1 * q**5
        C03 = M6 * (1 - (1 + i_mensual_1) ** -n3) / i_mensual_1
        tercera_renta = C03 * (1 + i_mensual_1) ** (-(n_meses_i1 - n3))

        # Calculamos la cuarta renta (normal)
        n4 = 12 - n3
        M6 = M1 * q**5
        C04 = M6 * (1 - (1 + i_mensual_2) ** -n4) / i_mensual_2
        cuarta_renta = C04 * (1 + i_mensual_1) ** (-n_meses_i1)

        # Calculamos la quinta renta (geométrica)
        n5 = 13
        M7 = M1 * q**6 * 12
        C05_1 = interes2 / j2 * M7 * \
            (1 - (q ** n5) * (1 + interes2) ** -n5) / (1 + interes2 - q)
        C05_2 = C05_1 * (1 + i_mensual_2) ** -n4
        quinta_renta = C05_2 * (1 + i_mensual_1)**(-n_meses_i1)

        # Calculamos la quinta renta (normal)
        n6 = 174 - (n5*12) - n3
        M19 = M1 * q**18
        C06_1 = M19 * (1 - (1 + i_mensual_2) ** -n6) / i_mensual_2
        C06_2 = C06_1 * (1 + i_mensual_2) ** (-(174 - n6))
        sexta_renta = C06_2 * (1 + i_mensual_1) ** -n_meses_i1

    # RENTAS JUBILADOS EN JUNIO
    if fecha_jubilacion_exacta.month == 6:

        # Calculamos la primera renta (normal)
        M1 = (row['salario_anual'] * value) / 12
        n1 = 6
        primera_renta = M1 * (1 - (1 + i_mensual_1) ** -n1) / i_mensual_1

        # Calculamos la segunda renta (geométrica)
        n2 = 5
        M2 = M1 * q * 12
        C02 = interes1 / j1 * M2 * \
            (1 - (q ** n2) * (1 + interes1) ** -n2) / (1 + interes1 - q)
        segunda_renta = C02 * (1 + i_mensual_1) ** -n1

        # Calculamos la tercera renta (geométrica)
        n3 = 14
        M7 = M1 * q**6 * 12
        C03 = interes2 / j2 * M7 * \
            (1 - (q ** n3) * (1 + interes2) ** -n3) / (1 + interes2 - q)
        tercera_renta = C03 * (1 + i_mensual_1) ** -n_meses_i1

        # Calculamos la cuarta renta (normal)
        n4 = 6
        M21 = M1 * q**20
        C04_1 = M21 * (1 - (1 + i_mensual_2) ** -n4) / i_mensual_2
        C04_2 = C04_1 * (1 + i_mensual_2) ** -168
        cuarta_renta = C04_2 * (1 + i_mensual_1) ** (-n_meses_i1)

    # RENTAS JUBILADOS DE JULIO A NOVIEMBRE
    if fecha_jubilacion_exacta.month in range(7, 11+1):

        # Calculamos la primera renta (normal)
        n1 = 12 - fecha_jubilacion_exacta.month
        M1 = (row['salario_anual'] * value) / 12
        primera_renta = M1 * (1 - (1 + i_mensual_1) ** -n1) / i_mensual_1

        # Calculamos la segunda renta (geométrica)
        n2 = 5
        M2 = M1 * q * 12
        C02 = interes1 / j1 * M2 * \
            (1 - (q ** n2) * (1 + interes1) ** -n2) / (1 + interes1 - q)
        segunda_renta = C02 * (1 + i_mensual_1) ** -n1

        # Calculamos la tercera renta (normal)
        n3 = (5*12 + 6) - (n1 + 5*12)
        M7 = M1 * q**6
        C03 = M7 * (1 - (1 + i_mensual_1) ** - n3) / i_mensual_1
        tercera_renta = C03 * (1 + i_mensual_1) ** (-(n_meses_i1 - n3))

        # Calculamos la cuarta renta (normal)
        n4 = 12 - n3
        C04 = M7 * (1 - (1 + i_mensual_2) ** - n4) / i_mensual_2
        cuarta_renta = C04 * (1 + i_mensual_1) ** (-n_meses_i1)

        # Calculamos la quinta renta (geométrica)
        n5 = 13
        M8 = M1 * q**7 * 12
        C05_1 = interes2 / j2 * M2 * \
            (1 - (q ** n5) * (1 + interes2) ** -n5) / (1 + interes2 - q)
        C05_2 = C05_1 * (1 + i_mensual_2) ** -n4
        quinta_renta = C05_2 * (1 + i_mensual_1) ** (-n_meses_i1)

        # Calculamos la sexta renta (normal)
        n6 = 174 - (n5*12) - n3
        M20 = M1 * q**19
        C06_1 = M20 * (1 - (1 + i_mensual_2) ** - n6) / i_mensual_2
        C06_2 = C06_1 * (1 + i_mensual_2) ** (174 - n6)
        sexta_renta = C06_2 * (1 + i_mensual_1) ** (-n_meses_i1)

    # RENTAS JUBILADOS EN DICIEMBRE
    if fecha_jubilacion_exacta.month == 12:

        # Calculamos la primera renta (geométrica)
        M1 = (row['salario_anual'] * value) / 12
        n1 = 5
        M2 = M1 * q * 12
        primera_renta = interes1 / j1 * M2 * \
            (1 - (q ** n1) * (1 + interes1) ** -n1) / (1 + interes1 - q)

        # Calculamos la segunda renta (normal)
        M7 = M1 * q**6
        n2 = 6
        C02 = M7 * (1 - (1 + i_mensual_1) ** -n2) / i_mensual_1
        segunda_renta = C02 * (1 + i_mensual_1)**-(n_meses_i1 - n2)

        # Calculamos la tercera renta (normal)
        n3 = 6
        C03 = M7 * (1 - (1 + i_mensual_2) ** -n3) / i_mensual_2
        tercera_renta = C03 * (1 + i_mensual_1)**-n_meses_i1

        # Calculamos la cuarta renta (geometrica)
        n4 = 14
        M8 = M1 * q**7 * 12
        C04_1 = interes2 / j2 * M8 * \
            (1 - (q ** n4) * (1 + interes2) ** -n4) / (1 + interes2 - q)
        C04_2 = C04_1 * (1 + i_mensual_2) ** -n3
        cuarta_renta = C04_2 * (1 + i_mensual_1) ** -n_meses_i1

    # Actualizamos el DataFrame
    # row['M1'] = primera_renta  ### para que????
    row['M1'] = M1
    row['primera_renta'] = primera_renta
    row['segunda_renta'] = segunda_renta
    row['tercera_renta'] = tercera_renta
    row['cuarta_renta'] = cuarta_renta

    suma_total_renta = primera_renta + segunda_renta + tercera_renta + cuarta_renta
    if 'quinta_renta' in locals():
        suma_total_renta += quinta_renta
    if 'sexta_renta' in locals():
        suma_total_renta += sexta_renta

    row[f'RENTA_F_{n}'] = suma_total_renta

    anos_aportaciones_1 = 10
    anos_aportaciones_2 = (fecha_jubilacion_exacta -
                           datetime(2024, 1, 1)).days / 365 - anos_aportaciones_1
    meses_rest = (fecha_jubilacion_exacta - datetime(2024, 1, 1)).days // 30
    i_aportaciones_1 = 0.02
    i_aportaciones_2 = 0.01
    i1_aport = (1 + i_aportaciones_1)**(1/12) - 1

    # Aplicamos el interés correspondiente
    if anos_aportaciones_2 <= 0:
        anos_aportaciones_1 = (fecha_jubilacion_exacta -
                               datetime(2024, 1, 1)).days / 365

        VALOR_TOTAL_2024 = (row[f'RENTA_F_{n}']*(1+i1_aport)**(-meses_rest))
        VALOR_TOTAL_2024
    else:
        VALOR_TOTAL_2024 = (row[f'RENTA_F_{n}']*(1+i_aportaciones_2)**(-anos_aportaciones_2))*(
            1+i_aportaciones_1)**(-anos_aportaciones_1)

    # Actualizamos la columna 'Suma_total_renta_2024' con el valor calculado
    row[f'ACTU_2024_{n}_(VA)'] = VALOR_TOTAL_2024
    return row


##################################################################################################
# CALCULO DE TERMINOS M , ESTE VALOR ES CONSTANTE E INAMOVIBLE.


def calcular_renta_mensual(row, n=0):
    # Calculamos la cantidad total de meses restantes hasta la jubilación desde enero de 2024

    # Valores constantes
    i_1 = 0.02
    i_2 = 0.01
    i12_1 = (1 + i_1)**(1/12) - 1
    i12_2 = (1 + i_2)**(1/12) - 1

    # Calculamos la renta mensual
    meses_1 = 10 * 12
    meses_2 = math.ceil(
        (row['fecha_jubilacion_base'] - datetime(2024, 1, 1)).days / 30 - meses_1)
    if meses_2 >= 0:
        M = row[f'ACTU_2024_{n}_(VA)']/((1 - (1 + i12_1)**(-meses_1))/i12_1 + (
            ((1 - (1 + i12_2)**(-meses_2))/i12_2)*(1+i12_1)**(-meses_1)))
    else:
        meses_1 = math.ceil(
            (row['fecha_jubilacion_base'] - datetime(2024, 1, 1)).days / 30)
        M = row[f'ACTU_2024_{n}_(VA)']/((1 - (1 + i12_1)**(-meses_1))/i12_1)

    # Actualizamos la columna 'renta_mensual_hasta_jubilacion'
    row['M'] = M

    return row


####################################################################################################
# FUNCION QUE CALCULA EL VALOR ACTUAL DE UNA RENTA CON LOS VALORES M CONSTANTES, SOLO HASTA EL MES N.

def calcular_rentas_en_terminos_constantes_hasta_n_VS(row, n):

    hoy = pd.to_datetime('2024-01-01', format='%Y-%m-%d')

    # queremos sacar n meses antes
    fecha_jubilacion_antes_desp = row['fecha_jubilacion_base'] + \
        relativedelta(months=n)

    meses_a = math.ceil((fecha_jubilacion_antes_desp - hoy).days / 30)
    # Valores constantes
    i_1 = 0.02
    i_2 = 0.01
    i12_1 = (1 + i_1)**(1/12) - 1
    i12_2 = (1 + i_2)**(1/12) - 1
    #
    meses_1 = 10 * 12
    meses_2 = math.ceil(
        (fecha_jubilacion_antes_desp - hoy).days / 30 - meses_1)

    if meses_a > meses_1:
        # queremos sacar el valor actual de la renta a n meses, en este caso, por debajo de la media
        segunda_renta = (((1-(1+i12_2)**(-meses_2))/i12_2) *
                         row['M']) * ((1+i12_1)**(-meses_1))
        primera_renta = ((1-(1+i12_1)**(-meses_1))/i12_1)*row['M']
        renta_a = primera_renta + segunda_renta

    else:
        renta_a = ((1-(1+i12_1)**(-meses_a))/i12_1)*row['M']

    # Actualizamos la columna 'renta_mensual_hasta_jubilacion'
    row[f'ACTU_2024_{n}(VS)'] = renta_a

    return row


# apartado de flask;
def calculo_rentas_VA_i(row, n=0, i=0, qn=0):
    fecha_jubilacion_exacta = pd.to_datetime(
        str(row['fecha_jubilacion'].strftime('%Y-%m')) + '-01').tz_localize(None)

    row['fecha_jubilacion_exacta'] = fecha_jubilacion_exacta
    # Calculamos los años en la empresa y n de periodos de 5 años en la empresa
    anos_en_empresa = (fecha_jubilacion_exacta.year -
                       row['FECHA ENTRADA'].year)
    periodos_5_anos = anos_en_empresa // 5

    # Condicion de no pasar del 15%
    if periodos_5_anos * 0.0175 > 0.15:
        value = 0.15
    else:
        value = periodos_5_anos * 0.0175

    # Valores constantes
    n_meses_i1 = 5 * 12 + 6
    interes1 = 0.01 + i
    interes2 = 0.02 + i
    i_mensual_1 = (1.01) ** (1/12) - 1
    i_mensual_2 = (1.02) ** (1/12) - 1
    k = 12
    q = 1.05 + qn
    j1 = k * i_mensual_1
    j2 = k * i_mensual_2

    # RENTAS JUBILADOS DE ENERO A MAYO
    if fecha_jubilacion_exacta.month in range(1, 5+1):

        # Calculamos la primera renta (normal)
        n1 = 12 - fecha_jubilacion_exacta.month
        M1 = (row['salario_anual'] * value) / 12
        primera_renta = M1 * (1 - (1 + i_mensual_1) ** -n1) / i_mensual_1

        # Calculamos la segunda renta (geométrica)
        n2 = 4
        M2 = M1 * q * 12
        C02 = interes1 / j1 * M2 * \
            (1 - (q ** n2) * (1 + interes1) ** -n2) / (1 + interes1 - q)
        segunda_renta = C02 * (1 + i_mensual_1) ** (-n1)

        # Calculamos la tercera renta (normal)
        n3 = n_meses_i1 - (n1 + 4*12)
        M6 = M1 * q**5
        C03 = M6 * (1 - (1 + i_mensual_1) ** -n3) / i_mensual_1
        tercera_renta = C03 * (1 + i_mensual_1) ** (-(n_meses_i1 - n3))

        # Calculamos la cuarta renta (normal)
        n4 = 12 - n3
        M6 = M1 * q**5
        C04 = M6 * (1 - (1 + i_mensual_2) ** -n4) / i_mensual_2
        cuarta_renta = C04 * (1 + i_mensual_1) ** (-n_meses_i1)

        # Calculamos la quinta renta (geométrica)
        n5 = 13
        M7 = M1 * q**6 * 12
        C05_1 = interes2 / j2 * M7 * \
            (1 - (q ** n5) * (1 + interes2) ** -n5) / (1 + interes2 - q)
        C05_2 = C05_1 * (1 + i_mensual_2) ** -n4
        quinta_renta = C05_2 * (1 + i_mensual_1)**(-n_meses_i1)

        # Calculamos la quinta renta (normal)
        n6 = 174 - (n5*12) - n3
        M19 = M1 * q**18
        C06_1 = M19 * (1 - (1 + i_mensual_2) ** -n6) / i_mensual_2
        C06_2 = C06_1 * (1 + i_mensual_2) ** (-(174 - n6))
        sexta_renta = C06_2 * (1 + i_mensual_1) ** -n_meses_i1

    # RENTAS JUBILADOS EN JUNIO
    if fecha_jubilacion_exacta.month == 6:

        # Calculamos la primera renta (normal)
        M1 = (row['salario_anual'] * value) / 12
        n1 = 6
        primera_renta = M1 * (1 - (1 + i_mensual_1) ** -n1) / i_mensual_1

        # Calculamos la segunda renta (geométrica)
        n2 = 5
        M2 = M1 * q * 12
        C02 = interes1 / j1 * M2 * \
            (1 - (q ** n2) * (1 + interes1) ** -n2) / (1 + interes1 - q)
        segunda_renta = C02 * (1 + i_mensual_1) ** -n1

        # Calculamos la tercera renta (geométrica)
        n3 = 14
        M7 = M1 * q**6 * 12
        C03 = interes2 / j2 * M7 * \
            (1 - (q ** n3) * (1 + interes2) ** -n3) / (1 + interes2 - q)
        tercera_renta = C03 * (1 + i_mensual_1) ** -n_meses_i1

        # Calculamos la cuarta renta (normal)
        n4 = 6
        M21 = M1 * q**20
        C04_1 = M21 * (1 - (1 + i_mensual_2) ** -n4) / i_mensual_2
        C04_2 = C04_1 * (1 + i_mensual_2) ** -168
        cuarta_renta = C04_2 * (1 + i_mensual_1) ** (-n_meses_i1)

    # RENTAS JUBILADOS DE JULIO A NOVIEMBRE
    if fecha_jubilacion_exacta.month in range(7, 11+1):

        # Calculamos la primera renta (normal)
        n1 = 12 - fecha_jubilacion_exacta.month
        M1 = (row['salario_anual'] * value) / 12
        primera_renta = M1 * (1 - (1 + i_mensual_1) ** -n1) / i_mensual_1

        # Calculamos la segunda renta (geométrica)
        n2 = 5
        M2 = M1 * q * 12
        C02 = interes1 / j1 * M2 * \
            (1 - (q ** n2) * (1 + interes1) ** -n2) / (1 + interes1 - q)
        segunda_renta = C02 * (1 + i_mensual_1) ** -n1

        # Calculamos la tercera renta (normal)
        n3 = (5*12 + 6) - (n1 + 5*12)
        M7 = M1 * q**6
        C03 = M7 * (1 - (1 + i_mensual_1) ** - n3) / i_mensual_1
        tercera_renta = C03 * (1 + i_mensual_1) ** (-(n_meses_i1 - n3))

        # Calculamos la cuarta renta (normal)
        n4 = 12 - n3
        C04 = M7 * (1 - (1 + i_mensual_2) ** - n4) / i_mensual_2
        cuarta_renta = C04 * (1 + i_mensual_1) ** (-n_meses_i1)

        # Calculamos la quinta renta (geométrica)
        n5 = 13
        M8 = M1 * q**7 * 12
        C05_1 = interes2 / j2 * M2 * \
            (1 - (q ** n5) * (1 + interes2) ** -n5) / (1 + interes2 - q)
        C05_2 = C05_1 * (1 + i_mensual_2) ** -n4
        quinta_renta = C05_2 * (1 + i_mensual_1) ** (-n_meses_i1)

        # Calculamos la sexta renta (normal)
        n6 = 174 - (n5*12) - n3
        M20 = M1 * q**19
        C06_1 = M20 * (1 - (1 + i_mensual_2) ** - n6) / i_mensual_2
        C06_2 = C06_1 * (1 + i_mensual_2) ** (174 - n6)
        sexta_renta = C06_2 * (1 + i_mensual_1) ** (-n_meses_i1)

    # RENTAS JUBILADOS EN DICIEMBRE
    if fecha_jubilacion_exacta.month == 12:

        # Calculamos la primera renta (geométrica)
        M1 = (row['salario_anual'] * value) / 12
        n1 = 5
        M2 = M1 * q * 12
        primera_renta = interes1 / j1 * M2 * \
            (1 - (q ** n1) * (1 + interes1) ** -n1) / (1 + interes1 - q)

        # Calculamos la segunda renta (normal)
        M7 = M1 * q**6
        n2 = 6
        C02 = M7 * (1 - (1 + i_mensual_1) ** -n2) / i_mensual_1
        segunda_renta = C02 * (1 + i_mensual_1)**-(n_meses_i1 - n2)

        # Calculamos la tercera renta (normal)
        n3 = 6
        C03 = M7 * (1 - (1 + i_mensual_2) ** -n3) / i_mensual_2
        tercera_renta = C03 * (1 + i_mensual_1)**-n_meses_i1

        # Calculamos la cuarta renta (geometrica)
        n4 = 14
        M8 = M1 * q**7 * 12
        C04_1 = interes2 / j2 * M8 * \
            (1 - (q ** n4) * (1 + interes2) ** -n4) / (1 + interes2 - q)
        C04_2 = C04_1 * (1 + i_mensual_2) ** -n3
        cuarta_renta = C04_2 * (1 + i_mensual_1) ** -n_meses_i1

    # Actualizamos el DataFrame
    # row['M1'] = primera_renta  ### para que????
    row['M1'] = M1
    row['primera_renta'] = primera_renta
    row['segunda_renta'] = segunda_renta
    row['tercera_renta'] = tercera_renta
    row['cuarta_renta'] = cuarta_renta

    suma_total_renta = primera_renta + segunda_renta + tercera_renta + cuarta_renta
    if 'quinta_renta' in locals():
        suma_total_renta += quinta_renta
    if 'sexta_renta' in locals():
        suma_total_renta += sexta_renta

    row[f'RENTA_F_{n}'] = suma_total_renta

    anos_aportaciones_1 = 10
    anos_aportaciones_2 = (fecha_jubilacion_exacta -
                           datetime(2024, 1, 1)).days / 365 - anos_aportaciones_1
    meses_rest = (fecha_jubilacion_exacta - datetime(2024, 1, 1)).days // 30
    i_aportaciones_1 = 0.02
    i_aportaciones_2 = 0.01
    i1_aport = (1 + i_aportaciones_1)**(1/12) - 1

    # Aplicamos el interés correspondiente
    if anos_aportaciones_2 <= 0:
        anos_aportaciones_1 = (fecha_jubilacion_exacta -
                               datetime(2024, 1, 1)).days / 365

        VALOR_TOTAL_2024 = (row[f'RENTA_F_{n}']*(1+i1_aport)**(-meses_rest))
        VALOR_TOTAL_2024
    else:
        VALOR_TOTAL_2024 = (row[f'RENTA_F_{n}']*(1+i_aportaciones_2)**(-anos_aportaciones_2))*(
            1+i_aportaciones_1)**(-anos_aportaciones_1)

    # Actualizamos la columna 'Suma_total_renta_2024' con el valor calculado
    row[f'ACTU_2024_{n}_(VA)'] = VALOR_TOTAL_2024
    return row
